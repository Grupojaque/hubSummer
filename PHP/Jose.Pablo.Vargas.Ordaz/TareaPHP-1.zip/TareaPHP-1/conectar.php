<?php
define('DB_SERVER', 'localhost');
define('DB_NAME', 'aplicaciones_web');
define('DB_USER', 'admin');
define('DB_PASS', 'admin');
session_start();
if(isset($_POST['usuario']) && !empty($_POST['usuario']) &&
isset($_POST['pass']) && !empty($_POST['pass']))
		
{
	$con=mysql_connect(DB_SERVER, DB_USER, DB_PASS) or die(mysql_error("problemas al conectar server"));
	mysql_select_db(DB_NAME, $con) or die(mysql_error("problemas con la base de datos"));

	$Query = mysql_query("SELECT * FROM usuarios",$con);

	//$sel=mysql_query("SELECT username,pw,nombre,a_paterno,a_materno,admin,email,sexo,f_nacimiento FROM usuario WHERE username='$_POST[usuario]'",$con);
	$sel=mysql_query("SELECT * FROM usuarios WHERE username='$_POST[usuario]'",$con);
	$sesion=mysql_fetch_array($sel);


if($_POST['pass'] == $sesion['pass']){
	$_SESSION['user'] = $_POST['usuario'];
	



}else{
	echo "alert('Datos incorrectos')";

	echo "<head>";
	echo "<script languaje=JavaScript>";
	echo "location.href='Form.php'";
	echo "</script>";
	echo "</head>";

}

}else{
	echo "<head>";
	echo "<script languaje=JavaScript>";
	echo "location.href='Form.php'";
	//echo "window.alert('Debes llenas ambos campos')";
	echo "</script>";
	echo "</head>";
}

mysql_close($con);
	
?>








