
<!DOCTYPE html>
<!--<?php //include "conectar.php";?>-->
<head>
	<link href='http://fonts.googleapis.com/css?family=Bitter' rel='stylesheet' type='text/css'>
	<link href="css/bootstrap.min.css" rel="stylesheet">
<title>Registrar</title>
<meta charsetss="utf8">
</head>

<body>
<p><?php
			echo "<p class='saludo'>Bienvenido<br> $sesion[nombre] $sesion[a_paterno]!</p>";
	echo "holaaaaaaa";	
/*
if(isset($_POST['nombre']) && !empty($_POST['nombre']) &&
isset($_POST['paterno']) && !empty($_POST['paterno'])
isset($_POST['materno']) && 
isset($_POST['user']) && !empty($_POST['user']) &&
isset($_POST['pas1']) && !empty($_POST['pas1']) &&
isset($_POST['pas2']) && !empty($_POST['pas2']) &&
isset($_POST['email']) && !empty($_POST['email']) &&
isset($_POST['sexo']) && !empty($_POST['pass']) &&
$_POST['pas1'] == $_POST['pas2'])
{
//Conexion con la base
$sSQL="INSERT INTO usuario() VALUES ('null','$_post[user]','$_post[pas1]','$_post[admin]','$_post[email]',
 '$_post[nombre]','$_post[paterno]','$_post[materno]','$_post[sexo]','$_post[fnac]')";

mysql_query($sSQL, $con);

}else{
	echo "<h1>Verifica que has llenado todos los campos o que los passwords coincidan</h1>";
}

mysql_close($con)*/
?></p>

<h1><div align="center">Registro Actualizado</div></h1>


<div align="center"><a href="principal.php">Regresar</a></div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>
</html>

