<!DOCTYPE html>
<head>
<meta charset = "utf8" />
<link href="css/bootstrap.min.css" rel="stylesheet">
<head>

<body>
<form action = "registrar.php" method="post">
<table class="table" whith ="200" border= "0">
	<tr>
		<td>Nombre:</td>
		<td><input type="text" name= "nombre" /></td>
	</tr>
	<tr>
		<td>Apellido Paterno:</td>
		<td><input type="text" name= "paterno" /></td>
	</tr>
	<tr>
		<td>Apellido Materno:</td>
		<td><input type="text" name= "materno" /></td>
	</tr>
	<tr>
		<td>Nombre de usuario:</td>
		<td><input type="text" name= "user" /></td>
	</tr>
	<tr>
		<td>Password:</td>
		<td><input type="text" name= "pas1" /></td>
	</tr>
	<tr>
		<td>Confirma Password:</td>
		<td><input type="text" name= "pas2" /></td>
	</tr>
	<tr>
		<td>E-mail:</td>
		<td><input type="text" name= "email" /></td>
	</tr>
	<tr>
	<tr>
		<td>Fecha de nacimiento:</td>
		<td><input type="text" name= "fnac" placeholder="aaaa-mm-dd" /></td>
	</tr>
		<td><input type="radio" name="sex" value="H">Hombre<br></td>
		<td><input type="radio" name="sex" value="M">Mujer</td>
	</tr>
	<tr>
		<td><input type="checkbox" name= "admin" value="1">Admin</td>
		<td></td>
	</tr>
	<tr>
		<td><td>
		<td><input type="submit"  Value = "Registrar" /><td>
	</tr>
	 <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>
</html>
