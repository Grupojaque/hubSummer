<!DOCTYPE html>
<?php include "conectar.php"; ?>
<head>
	<link href='http://fonts.googleapis.com/css?family=Bitter' rel='stylesheet' type='text/css'>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/principal.css">
</head>

<body>
<header>
	<seccion>
		<p><?php
		if(isset($_SESSION['user']))
		{
			echo "<p class='saludo'>Bienvenido<br> $sesion[nombre] $sesion[a_paterno]!</p>";
		}
		//if(isset($sesion['admin'] == '1')){
		//		echo "<p class='saludo'>Administrador</p>"

		//	}
				
		   ?>
		</p>
	</seccion>
</header>

	<seccion id="tablas" class="row">
		<div class="col-md-9 col-md-push-3">
		<?php
		echo '<table class="table table-hover">', '<thead><tr><th>Nombre Completo</th><th>E-mail</th><th>Sexo</th><th>Edad</th></tr></thead>', '<tbody>';
		
		while ($row = mysql_fetch_assoc($Query)) {

		// cambia el 1 o 0 del sexo por H y M
			if($row[sexo]==1){
				$sex = "H";
			}else{
				$sex = "F";
			}

		//calcular edad
	    		$dia = date('j');
				$mes = date('n');
				$anio = date('Y');

				$nacimiento = explode("-", $row[f_nacimiento]);
				$dn = $nacimiento[2];
				$mn = $nacimiento[1];
				$an = $nacimiento[0];
				if (($mn == $mes) && ($dn>$dia)){
					$anio=($anio - 1);
				}

				if ($mn > $mes){
					$anio = ($anio -1);
				}
				$edad = ($anio-$an);

		
			
			echo "<tr>	<td>{$row['nombre'] } {$row['a_paterno']} {$row['a_materno']}</td>
						<td>{$row['email']}</td>
						<td>$sex</td>
						<td>$edad</td>
				  </tr>";

		}
		echo '</tbody></table>';
		?>
	    </div>

	    <div id="opciones" class="col-md-3 col-md-pull-9">
	    	<a href="mostrar.php"<button type="button" id="mostrar" class = "btn btn-primary ">Mostrar</button></a><br><br>
	    	<a href="registro.php"<button type="button" id="agregar" class = "btn btn-success" >Agregar</button></a><br><br>
			<button type="button" id="eliminar" class = "btn btn-danger">Eliminar</button><br><br>
			<button type="button" id="editar" class = "btn btn-warning">Editar</button><br><br>
			<a href = "Form.php" <button type="button" onclick='session_destroy()' id="eliminar" class = "btn btn-danger">Cerrar sesion</button></a>

	    </div>
	</seccion>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>
</html>


	

	
