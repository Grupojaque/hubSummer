<!DOCTYPE html>
<head>
<meta  charset="utf8"/>
<link href="css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="css/Form.css">
<link href='http://fonts.googleapis.com/css?family=Droid+Serif' rel='stylesheet' type='text/css'>
<title>Tarea1 PHP</title>
</head>

<body>
  <header>
    <h1>Tarea 1<br>   PHP</h1>
  </header>

<section id="loge">
<form role="form" action="principal.php" method="post">
  <div class="input-group input-group-lg">
  <span class="input-group-addon">User</span>
  <input type="text" class="form-control" name="usuario"placeholder="Username"><br /> <br />
  </div><br />

  <div class="input-group input-group-lg">
  <span class="input-group-addon">Pass</span>
  <input type="password" class="form-control" name="pass"  placeholder="Password"><br /> <br />
  </div><br /> <br />
  <input id="enviar" type="submit" value="Entrar">
</form>
</section>
<!--<input type="submit" id="entrar" class="btn btn-primary btn-lg btn-block" value="Entrar!">-->


 <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</body>
</html>
 