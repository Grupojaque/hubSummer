<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="./bootstrap-3.2.0-dist/css/bootstrap.min.css">

</head>
<body>
	<head class="page-header">
  		<h1>Bienvenido! <small>Inicia Sesión</small></h1>
	</head>
	<section>
	<form role="form" method="post" action="Tarea1.php">
		<article> Ingresa tus datos
		</article>
		<article>
			<input type="text" placeholder="Usuario" name="MiUsuario">
			<input type="text" placeholder="Contraseña" name="MiContrasena">
			<button type="submit" class="btn btn-default navbar-btn">Sign in</button>
		</article>
	</form>
	</section>
	
<?php
	session_start();
	//session.auto_start;
	include "connection.php";
	
	
	if (!empty($_POST)) {
		$mius=$_POST['MiUsuario']; 
		$micon=$_POST['MiContrasena'];
	
		$connect = mysql_connect(DB_SERVER, DB_USER, DB_PASS);
		mysql_select_db(DB_NAME, $connect) or die(mysql_error($connect));

		$myQuery2 = mysql_query("SELECT * FROM usuarios WHERE username='$mius' and pass='$micon'", $connect);
		$cont=mysql_num_rows($myQuery2);
			
		if ($cont == 1){
			$_SESSION["mius"]=$mius;
			$_SESSION["micon"]=$micon; 
			header("location:Tarea1_2.php");
			}
			else {
			echo "Usuario o contraseña incorrectos";
		}
	}
	//session_write_close() 

?>
</body>

</html>