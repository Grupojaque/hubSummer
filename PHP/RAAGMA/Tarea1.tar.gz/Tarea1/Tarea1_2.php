<html>
	<head>
		<meta charset="utf-8">
		<link rel="shortcut icon" href="public/img/favicon.ico" />
		<link href="public/css/bootstrap.min.css" rel="stylesheet" media="screen">
		<link href="public/css/bootstrap-theme.min.css" rel="stylesheet" media="screen">		
		<link href="public/css/main.css" rel="stylesheet" media="screen">
	</head>
	<body>

	</body>
		<section class="col-md-9 well">
		<?php
		session_start();
			include "connection.php";
			$connect = mysql_connect(DB_SERVER, DB_USER, DB_PASS);
			
			echo '<table class="table table-hover">', '<thead><tr><th>Nombre</th><th>Apellido Paterno</th><th>Apellido Materno</th><th>E-MAIL</th><th>Sexo</th><th>Fecha de Nacimiento</th></tr></thead>', '<tbody>';
			
			
			mysql_select_db(DB_NAME, $connect) or die(mysql_error($connect));

			$myQuery = mysql_query("SELECT * FROM usuarios", $connect);
			
						
			while ($row = mysql_fetch_assoc($myQuery)) {
				
				
				echo "<tr>	<td>{$row['nombre']}</td>
							<td>{$row['a_paterno']}</td>
							<td>{$row['a_materno']}</td>
							<td>{$row['email']}</td>
							<td>{$row['sexo']}</td>
							<td>{$row['f_nacimiento']}</td>
							<td><button>Editar</button></td>
							<td><button>Borrar</button></td>
					  </tr>";
			}


			echo '</tbody></table>';
			mysql_close($connect);

		
			?>
		</section>
</html>