Nombre: Raquel Aguilar Marquez
Tarea 1

Hola, esto es lo que pude hace. No es mucho, tuve problemas con la variable $_SESSION :(