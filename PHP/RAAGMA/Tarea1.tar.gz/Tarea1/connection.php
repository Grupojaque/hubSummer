<?php

define('DB_SERVER', 'localhost');
define('DB_NAME', 'aplicaciones_web');
define('DB_USER', 'admin');
define('DB_PASS', 'admin');

class Connection {
	
	private $connect;
	private $sqlScript;

	function Connection($userScript = 'SELECT * FROM usuarios') {

		$this -> sqlScript = $userScript;
	}

	public function consulta() {

		$connect = mysql_connect(DB_SERVER, DB_USER, DB_PASS);
		
		echo '<table class="table table-hover">', '<thead><tr><th>ID</th><th>Nombre Completo</th><th>E-MAIL</th></tr></thead>', '<tbody>';
		
		mysql_select_db(DB_NAME, $connect) or die(mysql_error($connect));

		$myQuery = mysql_query($this -> sqlScript, $connect);
		
		
		while ($row = mysql_fetch_assoc($myQuery)) {
			
			echo "<tr>	<td>{$row['id']}</td>
						<td>{$row['nombre'] } {$row['a_paterno']} {$row['a_materno']}</td>
						<td>{$row['email']}</td>
				  </tr>";
		}

		echo '</tbody></table>';
		mysql_close($connect);

	}
	public function consulta2() {

		$connect = mysql_connect(DB_SERVER, DB_USER, DB_PASS);
				
		
		

		echo '</tbody></table>';
		mysql_close($connect);

	}

}
?>