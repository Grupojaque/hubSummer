  	<div class="panel panel-primary">Información - Problemas - Sugerencias</div>
    <div class="panel panel-success">Contactar: luis.felipe.2323@gmail.com</div>
  

      <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
          <!-- Include all compiled plugins (below), or include individual files as needed -->
      <script src="js/bootstrap.min.js"></script>
  </body>

</html>