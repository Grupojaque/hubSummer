<?php include "cabecera.php" ?>

      <nav class="navbar navbar-inverse" role="navigation">
        ...
      </nav>

      <div class="jumbotron">
		  <h1>Usuario No Existe</h1>
		  <p>

		  </p>

		  <p><br><br><a href="login.php" class="btn btn-default" role="button">Try again</a></p>
	  </div>

<?php include "pie.php" ?>