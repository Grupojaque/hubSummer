<!DOCTYPE html>
<html>
    <head>
      <title>Aplicación WEB</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/ejemplo4.css" rel="stylesheet">

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    </head>

  <body>

      <div class="page-header">
      <h1>Tarea No. 1 de PHP <small>Hub Summer</small></h1>
      </div>